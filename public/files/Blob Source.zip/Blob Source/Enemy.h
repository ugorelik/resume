#pragma once
#ifndef ENEMY_H
#define ENEMY_H
#include "Entity.h"

// Will have AI
class Enemy : public Entity {
public: 
	Enemy();
};

#endif