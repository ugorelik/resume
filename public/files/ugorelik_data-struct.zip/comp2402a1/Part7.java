package comp2402a1;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;


public abstract class Part7 {
	public static <T> void riffleShuffle(List<T> l) {
	    int stopLocation = l.size();
	    List<T> sub = new ArrayList<T>();
	        
	    for (T t : l.subList(l.size()/2, l.size())) {
	        sub.add(t);
	    }
	    
	    l.removeAll(sub);
	    
	    int n = 0;
	    int originalSize = l.size();
	    for (int i = 0; i < originalSize + sub.size(); i ++ ) {
	        
	        if (n >= originalSize) {
	            l.add(sub.get(n++));
	        } else if (i % 2 == 1) {
                l.add(i, sub.get(n++));
	        }
	    }
	}

	/**
	 * Some example testing code
	 * @param args
	 */
	public static void main(String[] args) {
		testIt(new ArrayList<String>());
//		testIt(new LinkedList<String>());
	}
		
	public static void testIt(List<String> l) {
		String[] a = {"1", "3", "5", "7", "9", "2", "4", "6", "8", "10" };
//		String[] a = {"1", "3", "5", "7", "9", "2", "4", "6", "8"};
		for (String x : a) l.add(x);
		
		System.out.println(l);
		riffleShuffle(l);
		System.out.println(l);
	}
}
