package comp2402a1;

import java.util.AbstractList;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

public class Part8List<T> extends AbstractList<T> {

    private ArrayList<Object> list = new ArrayList<Object>();

    private int n = 0;

    public T get(int c) {

        if ((c < 0) || (c >= n)) {
            throw new ArrayIndexOutOfBoundsException();
        }

        T currentElement = null;
        int counter = 0;

        for (int i = 1; i < list.size(); i = i + 2) {

            currentElement = (T) list.get(i - 1);
            counter += (Integer) (list.get(i));

            if (counter > c) {
                return currentElement;
            }
        }

        return null;
    }

    public int size() {

        return n;
    }

    public boolean add(T element) {

        if ((n != 0) && ((T) (list.get(list.size() - 2))).equals(element)) {
            list.set(list.size() - 1, (Integer) list.get(list.size() - 1) + 1);
        } else {
            list.add(element);
            list.add(new Integer(1));
        }

        // Increase the size
        n++;
        

        return true;
    }

    public Iterator<T> iterator() {
        Iterator it = new Iterator<T>() {

            int realCounter = 0;
            int innerLoc = 1;
            int loc = 0;
            T currentElement = null;

            public boolean hasNext() {
                return (loc < n );
            }

            public T next() {
                
                if (innerLoc > ((Integer) list.get(realCounter + 1))) {
                    realCounter += 2;
                    currentElement = (T) list.get(realCounter);
                    innerLoc = 1;
                } 

                innerLoc++;
                loc++;                

                if (currentElement == null) {
                    return currentElement = (T) list.get(realCounter);
                }
                
                return currentElement;
            }

            public void remove() {

                list.set(realCounter, ((Integer) list.get(realCounter + 1)) - 1);

                if (((Integer) list.get(realCounter + 1)) == 0) {
                    list.remove(realCounter - 1);
                    list.remove(realCounter - 1);
                }

                loc--;
                n--;
            }

        };

        return it;
    }
    
    public void clear() {
        list = new ArrayList<Object>();
        n = 0;
    }
    
    
    public boolean contains(Object o) {
        
        for (int i = 0; i < list.size(); i+=2) {
            
            if (o.equals(list.get(i))) return true;
        }
        
        return false;
    }
    
    public boolean containsAll(Collection<?> c) {
        
        Collection simple = new ArrayList();
        
        for (int i = 0; i < list.size(); i+=2) {
            simple.add(list.get(i));
        }
        
        return simple.containsAll(c);
        
    }
    
    public boolean equals(Object o) {
        return super.equals(o);
    }
    
    public int hashCode(Object o) {
        return super.hashCode();
    }

    public int indexOf(Object o) {
        
        int counter = 0;
        for (int i = 0; i < list.size(); i+=2) {
            
            
            int num = ((Integer)list.get(i + 1));
            
            
            if (o.equals(list.get(i))) {
                
                return counter;
            }
            
            counter += num;
        }
        
        return -1;
    }
    
    public boolean isEmpty() {
        
        return n==0;
    }
    

    public boolean retainAll (Collection<?> c) {
        
        Collection simple = new ArrayList();
        
        for (int i = 0; i < list.size(); i+=2) {
            if (!c.contains(list.get(i))) {
                list.remove(i);
                list.remove(i);
                i-=2;
                n--;
            }
            
        }
        n--;
        return true;
    }
    
    public boolean removeAll (Collection<?> c) {
        
        Collection simple = new ArrayList();
        
        for (int i = 0; i < list.size(); i+=2) {
            if (c.contains(list.get(i))) {
                list.remove(i);
                list.remove(i);
                i-=2;
                n--;
            }
            
        }
        n--;
        return true;
    }
    
    public List<T> sublist(int fromIndex, int toIndex){
        
        int elementNumber = 0;
        List<T> sublist = new ArrayList<T>();
        
        for (int i = 0; i < list.size(); i+=2) {
            
            for (int j = 0; j < ((Integer)list.get(i+1)); j++) {
                sublist.add(  ((T)list.get(i))  );
                
                elementNumber++;
            }
        }
        
        return sublist.subList(fromIndex, toIndex);
    }
    
    public Object[] toArray() {
        
        int arraySize = 0;
        for (int i = 1; i < list.size(); i+=2) {
            arraySize+=((Integer)list.get(i));
        }
        
        Object[] returning = new Object[arraySize];
        
        
        int loc = 0;
        for (int i = 0; i < list.size(); i+=2) {
            
            for (int j = 0; j < ((Integer)list.get(i+1)); j++) {
                returning[loc] = list.get(i);
                loc++;
            }
        }
        
        return returning;
    }
    


}
