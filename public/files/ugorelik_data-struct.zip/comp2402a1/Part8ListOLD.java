package comp2402a1;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.AbstractList;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Part8ListOLD<T> extends AbstractList<T> {

    private ArrayList<Object> list = new ArrayList<Object>();

    private int n = 0;

    @SuppressWarnings("unchecked")
    public T get(int c) {

        if ((c < 0) || (c >= n)) {
            throw new ArrayIndexOutOfBoundsException();
        }

        T currentElement = null;
        int counter = 0;

        for (int i = 1; i < list.size(); i = i + 2) {

            currentElement = (T) list.get(i - 1);
            counter += (Integer) (list.get(i));

            if (counter > c) {
                return currentElement;
            }
        }

        return null;
    }

    public int size() {

        return n;
    }

    public boolean add(T element) {

        if ((n != 0) && ((T) (list.get(list.size() - 2))).equals(element)) {
            list.set(list.size() - 1, (Integer) list.get(list.size() - 1) + 1);
        } else {
            list.add(element);
            list.add(new Integer(1));
        }

        // Increase the size
        n++;

        return true;
    }

    public Iterator<T> iterator() {
        Iterator it = new Iterator<T>() {

            int realCounter = 0;
            int innerLoc = 1;
            int loc = 0;

            T currentElement = (T) list.get(realCounter);

            public boolean hasNext() {
                return (loc < n );
            }

            public T next() {
                
                if (innerLoc > ((Integer) list.get(realCounter + 1))) {
                    realCounter += 2;
                    currentElement = (T) list.get(realCounter);
                    innerLoc = 1;
                } 

                innerLoc++;
                loc++;                

                return currentElement;
            }

            public void remove() {

                list.set(realCounter, ((Integer) list.get(realCounter + 1)) - 1);

                if (((Integer) list.get(realCounter + 1)) == 0) {
                    list.remove(realCounter - 1);
                    list.remove(realCounter - 1);
                }

                loc--;
                n--;
            }

        };

        return it;
    }

//    public static void main(String[] args) {
//
//        List<String> customList = new Part8List<String>();
//        List<String> customList2 = new ArrayList<String>();
//        
//
//       
//
//
//        try {
//            BufferedReader r;
//            PrintWriter w;
//            if (args.length == 0) {
//                r = new BufferedReader(new InputStreamReader(System.in));
//                w = new PrintWriter(System.out);
//            } else if (args.length == 1) {
//                r = new BufferedReader(new FileReader(args[0]));
//                w = new PrintWriter(System.out);            
//                
//                while(r.ready()) {
//                    
//                    String line = r.readLine();
//                    customList.add(line);
//                    customList2.add(line);
//                }
//                
//                
//            } else {
//                r = new BufferedReader(new FileReader(args[0]));
//                w = new PrintWriter(new FileWriter(args[1]));
//            }
//            
//            
//            
//            System.out.println("ArrayList");
//            long start = System.nanoTime();
//
//            for (Iterator iterator = customList2.iterator(); iterator.hasNext();) {
//                iterator.next();
//            }
//            
//            w.flush();
//            long stop = System.nanoTime();
//            System.out.println("Execution time: " + 10e-9 * (stop-start));
//            
//            // MY LIST
//            System.out.println();System.out.println();System.out.println();
//            System.out.println("MINE");
//            start = System.nanoTime();
//
//            for (Iterator iterator = customList.iterator(); iterator.hasNext();) {
//                iterator.next();
//            }
//            
//            w.flush();
//            stop = System.nanoTime();
//            System.out.println("Execution time: " + 10e-9 * (stop-start));
//            
//            
//            
//        } catch (IOException e) {
//            System.err.println(e);
//            System.exit(-1);
//        }
//
//    }

}
