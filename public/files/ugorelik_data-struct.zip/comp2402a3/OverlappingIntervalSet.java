package comp2402a3;

import java.util.ArrayList;
import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;

/**
 * This class implements the IntervalSet interface for storing a set of
 * intervals, which may or may not be disjoint.
 * 
 * @author morin
 *
 * @param <K>
 */
public class OverlappingIntervalSet<K extends Comparable<K>> implements IntervalSet<K> {
	SortedSet<Interval<K>> intervals;
	
	public OverlappingIntervalSet() {
		intervals = new TreeSet<Interval<K>>();
	}
	
	public boolean add(Interval<K> i) {

	    Interval<K> returning = null;
	    
	    if (!intervals.isEmpty()) {
	        
//	        if (intervals.contains(i)) return false;
	        
	        // Check if it would be the head of the tail
	        if (intervals.last().b.compareTo(i.a) <= 0) {
	            // This means that tailset will fail
	            // but there will be no overlap
	            returning = i;
	        } else if (intervals.first().a.compareTo(i.b) >= 0 ) {
	            // This means there is no overlap in the head
	            returning = i;
	        } else {
	            
	            // Adding in between
	            // if there ise overlap...
	            Interval<K> first = null;
	            Interval<K> last = intervals.tailSet(new Interval<K>(i.a, i.a)).first(); // Grab the element where it would be
	            if (last.a.compareTo(i.a) <= 0 && last.b.compareTo(i.b) > 0) return false;                   // Check if that element contains it
	            
	            // TODO this might need another Saftey
	            
	            if (last == intervals.first()) {
	                first = intervals.first();
	            } else {
	                first = intervals.headSet(new Interval<K>(i.a, i.a)).last(); // Grab the element before it
	            }
	            
	           
	            
	            if (i.a.compareTo(first.b) >= 0 && i.b.compareTo(last.a) < 0) {
	                returning = i;
	            } else {
	             // There is overlap
	                Interval<K> firstOverlap = null;
	                Interval<K> lastOverlap = null;
	                
	                // Saftey
	                if (new Interval<K>(i.b,i.b).compareTo(intervals.last()) > 0) {
	                    lastOverlap = intervals.last();
	                } else {
	                    lastOverlap = intervals.tailSet(new Interval<K>(i.b,i.b)).first();
	                }
	                
	                // Saftey
	                if (new Interval<K>(i.a, i.a).compareTo(intervals.first()) <= 0) {
	                    firstOverlap = intervals.first();
	                } else {
	                    firstOverlap = intervals.headSet(new Interval<K>(i.a, i.a)).last();
	                }
	                
	                
	                
	                // Set returning
	                returning = new Interval<K>(firstOverlap.a, lastOverlap.b);

	                // Remove the intervals that have been merged
	                List<Interval<K>> temp = new ArrayList<Interval<K>>();
	                temp.addAll(intervals.subSet(firstOverlap, lastOverlap));
	                intervals.removeAll(temp);
	                if (!temp.isEmpty())
	                    intervals.remove(lastOverlap);
	            }
	            
	        }
	    } else { 
	        returning = i;
	    }
	    
	    return intervals.add(returning);
	}

	public void clear() {
		intervals.clear();
	}

	public boolean contains(K x) {
	    Interval<K> myInterval;
        Interval<K> i = new Interval<K>(x,x);
        
        if (i.a.compareTo(intervals.last().a) >= 0 ) {
            
            if ( i.a.compareTo(intervals.last().b) >= 0) return false;
            myInterval = intervals.last();
        } else {
            myInterval = intervals.tailSet(new Interval<K>(x, x)).first();
        }
        
        return (myInterval.a.compareTo(x) <= 0); 
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// run some tests for disjoint intervals
//		DumbIntervalSet.runTests(new OverlappingIntervalSet<Integer>());

		
		OverlappingIntervalSet<Integer> ds = new OverlappingIntervalSet<Integer>();
        
        ds.add(new Interval<Integer>(0, 3));
        ds.add(new Interval<Integer>(4, 8));
        ds.add(new Interval<Integer>(-16, -10));
//        ds.add(new Interval<Integer>(0, 8));
//        ds.add(new Interval<Integer> (2,2));   // Overlap
//        ds.add(new Interval<Integer>(10, 13));
//        ds.add(new Interval<Integer>(15, 18));
//        ds.add(new Interval<Integer>(-1, 0));
//        ds.add(new Interval<Integer>(0, 13));  // Overlap
//        ds.add(new Interval<Integer>(8, 11));  // Overlap
        
        
        System.out.println();
	}

}
