package comp2402a3;

import java.util.AbstractList;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * This class implements the List interface using a collection of arrays of
 * sizes 1, 2, 3, 4, and so on.  The main advantages of this over an 
 * implementation like ArrayList is that there is never more than O(sqrt(size())
 * space being used to store anything other than the List elements themselves.
 * Insertions and removals take O(size() - i) amortized time.
 * 
 * This provides a space-efficient implementation of an ArrayList.  
 * The total space used beyond what is required to store elements is O(sqrt(n)) 
 * @author morin
 *
 * @param <T> the type of objects stored in this list
 */
public class RootishArrayStack<T> extends AbstractList<T> {
    /**
	 * The type of objects stored in this list
	 */
	Factory<T> f;
	
	/*
	 * The blocks that contains the list elements
	 */
	List<BoundedArrayDeque<T>> blocks;
	
	/**
	 * The number of elements in the list
	 */
	int n;

	/**
	 * Convert a list index i into a block number
	 * TODO: This code is correct, but very slow!
	 * @param i
	 * @return the index of the block that contains list
	 *         element i
	 */
	protected int i2b(int i) {
		double db = 0.0; // TODO: Your code for computing b' goes here      
		int b = (int)Math.ceil(db);
		// this crutch can be used to ensure correctness
		// even if k is off by a small value
		while (b*(b+1)/2 >= i+1) b--;
		while ((b+1)*(b+2)/2 < i+1) b++;
		return b;
	}
	
	protected void grow() {
		blocks.add(new BoundedArrayDeque<T>(f.t, blocks.size()+1));
	}
	
	protected void shrink() {
		int r = blocks.size();
		while (r > 0 && (r-2)*(r-1)/2 >= n) {
			blocks.remove(blocks.size()-1);
			r--;
		}
	}
	
	public T get(int i) {
		if (i < 0 || i > n - 1) throw new IndexOutOfBoundsException();
		int b = i2b(i);
		int j = i - b*(b+1)/2;
		return blocks.get(b).get(j);	// This code was edited
	}

	public T set(int i, T x) {
		if (i < 0 || i > n - 1) throw new IndexOutOfBoundsException();
		int b = i2b(i);
		int j = i - b*(b+1)/2;
//		blocks.get(b).n++; // TODO this doesn't make sense// Increment the the number of elements in the list
		T y = blocks.get(b).get(j);
		blocks.get(b).set(j, x);
		
		return y;
	}
	
	public void add(int i, T x) {
		if (i < 0 || i > n) throw new IndexOutOfBoundsException();
		int r = blocks.size();
		int b = i2b(i);
		if (r*(r+1)/2 < n + 1) 
			grow();
		n++;
		
		// Shift the elements with pushes and pops
		for (int j = blocks.size() - 1; j > b; j--) {
		    if (j - 1 >= 0) {
		        blocks.get(j).offer(blocks.get(j - 1).pop());
		    }
		}
		
		// Add the element
		int locI = i - b * (b + 1) / 2;
		
		// This code needs to be removed to work properly
//		if (locI > blocks.get(b).n -1){
//			locI = blocks.get(b).n -1;
//		} // end code removal
			
		blocks.get(b).add(locI, x);
		// TODO Since we are using a array deque we can't add outside the boundry
		// so if locI > the number of elements we need to do something smart
	}
	
	public T remove(int i) {
		if (i < 0 || i > n - 1) throw new IndexOutOfBoundsException();
		T x = get(i);
		int b = i2b(i);
		int locI = i - b * (b + 1) / 2;
		
		// This time we shift first
		blocks.get(b).remove(locI);
		
		// Shift the elements with pushes and pops
		for (int j = b; j < blocks.size() - 2; j++) {
		    if (blocks.size() >= 1) {
		    	blocks.get(j).push(blocks.get(j + 1).poll());
		    }
		}
		
		n--;
		shrink();
		return x;
	}

	public int size() {
		return n;
	}

	public RootishArrayStack(Class<T> t) {
		f = new Factory<T>(t);
		n = 0;
		
		blocks = new ArrayList<BoundedArrayDeque<T>>();
	}
	
	public void clear() {
		blocks.clear();
		n = 0;
	}
	
	protected static <T> boolean listEquals(List<T> l1, List<T> l2) {
		if (l1.size() != l2.size()) {
			return false;
		}
		Iterator<T> i1 = l1.iterator();
		Iterator<T> i2 = l2.iterator();
		while (i1.hasNext()) {
			if (! i1.next().equals(i2.next())) {
				return false;
			}
		}
		return true;
	}
	
	public static void main(String[] args) {
		List<Integer> l = new RootishArrayStack<Integer>(Integer.class);
		
		l.add(0);
		l.add(1);
		l.add(2);
		l.add(3);
		l.add(4);
		l.add(5);
		l.add(6);
		l.add(7);
		l.add(8);
		l.add(9);
//		l.remove(1);
		
		System.out.println(l);
		
//		List<Integer> l2 = new ArrayList<Integer>();
//		// easy test - sequential addition
//		int n = 100;
//		for (int i = 0; i < n; i++) {
//			l.add(i);
//			l2.add(i);
//		}
//		Comp2402.myassert(listEquals(l, l2));
//		
//		// harder test - random addition and removal
//		for (int k = 0; k < 10; k++) {
//			l.clear();
//			l2.clear();
//			Random r = new Random();
//			for (int i = 0; i < n; i++) {
//				int j = r.nextInt(i+1);
//				l.add(j, i);
//				l2.add(j, i);
//			}
//			Comp2402.myassert(listEquals(l, l2));
//			for (int i = 0; i < n/4; i++) {
//				int j = r.nextInt(n-i);
//				l.remove(j);
//				l2.remove(j);
//			}
//			Comp2402.myassert(listEquals(l, l2));
//		}
//		l.clear();
//		l2.clear();
//		
//		// performance tests
//		n = 10000;
//		Random r = new Random();
//		System.out.print("Adding " + n + " elements...");
//		long start = System.nanoTime();		
//		for (int i = 0; i < n; i++) {
//			int j = r.nextInt(i+1);
//			l.add(j, i);
//			l2.add(j, i);
//		}
//		long stop = System.nanoTime();
//		double elapsed = 1e-9*(stop-start);
//		System.out.println("done (" + elapsed + "s) [ " 
//				+ (int)(((double)n)/elapsed) + " ops/sec ]");
//
//		System.out.print("Removing " + n/4 + " elements...");
//		start = System.nanoTime();		
//		for (int i = 0; i < n/4; i++) {
//			int j = r.nextInt(n-i);
//			l.remove(j);
//			l2.remove(j);
//		}
//		stop = System.nanoTime();
//		elapsed = 1e-9*(stop-start);
//		System.out.println("done (" + elapsed + "s) [ " 
//				+ (int)(((double)n)/elapsed) + " ops/sec ]");
	}	
}
