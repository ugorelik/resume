package comp2402a3;

import java.util.SortedSet;
import java.util.TreeSet;

/**
 * This class implements the IntervalSet interface for storing a set of
 * disjoint intervals
 * @author morin
 *
 * @param <K>
 */
public class DisjointIntervalSet<K extends Comparable<K>> implements IntervalSet<K> {
	SortedSet<Interval<K>> intervals;
	
	public DisjointIntervalSet() {
		intervals = new TreeSet<Interval<K>>();
	}
	
    public boolean add(Interval<K> i) {
        return intervals.add(i);
    }

	public void clear() {
		intervals.clear();
	}

    public boolean contains(K x) {
        
        Interval<K> myInterval;
        Interval<K> i = new Interval<K>(x,x);
        
        if (i.a.compareTo(intervals.last().a) >= 0 ) {
            
            if ( i.a.compareTo(intervals.last().b) >= 0) return false;
            myInterval = intervals.last();
        } else {
            myInterval = intervals.tailSet(new Interval<K>(x, x)).first();
        }
        
        return (myInterval.a.compareTo(x) <= 0); 
    }

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		DumbIntervalSet.runTests(new DisjointIntervalSet<Integer>());
	    
//	    DisjointIntervalSet<Integer> ds = new DisjointIntervalSet<Integer>();
//	    
//	    ds.add(new Interval<Integer>(0, 3));
//	    ds.add(new Interval<Integer>(5, 8));
//	    ds.add(new Interval<Integer> (2,2));   // Overlap
//	    ds.add(new Interval<Integer>(10, 13));
//	    ds.add(new Interval<Integer>(13, 16));
//	    ds.add(new Interval<Integer>(-1, 0));
//	    ds.add(new Interval<Integer>(0, 13));  // Overlap
//	    ds.add(new Interval<Integer>(8, 11));  // Overlap
//	    
//	    
//	    // [-1,0), [0,3), [5,8), [10,13), [13,16)
//	    System.out.println("tes");
	}

}
