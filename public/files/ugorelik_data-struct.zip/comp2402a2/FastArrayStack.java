package comp2402a2;

/**
 * This subclass of ArrayStack overrides some of its functions to make
 * them faster. In particular, it uses System.arraycopy() rather than for
 * loops copy elements between arrays and to shift them within arrays.
 * @author morin
 *
 * @param <T>
 */
public class FastArrayStack<T> extends ArrayStack<T> {
	public FastArrayStack(Class<T> t0) {
		super(t0);
	}

	protected void grow() {
		T[] b = f.newArray(a.length*2);
		System.arraycopy(a, 0, b, 0, n);
		a = b;
	}
	
	protected void shrink() {
		if (n > 0 && n < a.length / 3) {
			T[] b = f.newArray(n*2);
			System.arraycopy(a, 0, b, 0, n);
			a = b;
 		}
	}

	public void add(int i, T x) {
		if (i < 0 || i > n) throw new IndexOutOfBoundsException();
		if (n + 1 > a.length)
			grow();
		System.arraycopy(a, i, a, i+1, n-i); 
		a[i] = x;
		n++;
	}
	
	public T remove(int i) {
		if (i < 0 || i > n - 1) throw new IndexOutOfBoundsException();
		T x = a[i];
		System.arraycopy(a, i+1, a, i, n-i-1);
		n--; 
		shrink();
		return x;
	}
	
	public static void main(String[] args) {
		System.out.println(18&15);
		System.out.println(-1&15);
	}
}
