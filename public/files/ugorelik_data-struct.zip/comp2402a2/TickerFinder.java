package comp2402a2;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

/**
 * This class associates stock market symbols with company names so that one can
 * search for a company by name or by symbol.
 * 
 * This implementation is (deliberately) very slow. Each query does a linear
 * search through the list of company symbols (or names) and returns the first n
 * matches. This is not the correct way to use a Map, and a Map is probably not
 * the right data structure for this problem. Your job is to do better.
 * 
 * @author morin
 * 
 */
public class TickerFinder {
    /**
     * This maps stock ticker symbols onto company names. It allows us to
     * efficiently search for a company name given it symbol. Unfortunately, we
     * need more powerful searches than this, so we need to use a different (and
     * possibly more) data structures.
     */

    List<String> symbols;

    SortedMap<String, ArrayList<String>> companies;

    /**
     * Constructor
     */
    public TickerFinder() {
        companies = new TreeMap<String, ArrayList<String>>();
        symbols = new ArrayList<String>();
    }

    /**
     * Load a list of companies from the file named filename
     * 
     * @param filename
     *            - the name of the file to use
     */
    public void loadCompaniesFromFile(String filename) throws IOException {
        loadCompanies(new BufferedReader(new FileReader(filename)));
    }

    /**
     * @param r
     *            a BufferedReader to the use for reading.
     */
    protected void loadCompanies(BufferedReader r) throws IOException {
        String s;
        while ((s = r.readLine()) != null) {
            String[] parts = s.split(";");
            if (parts.length < 2) {
                throw new IOException("invalid input line");
            }
            String tobeAdded = "";

            parts[0] = parts[0].replaceAll("\"", ""); // stock symbol
            parts[1] = parts[1].replaceAll("\"", ""); // company name

            // Add the symbols
            tobeAdded = parts[0] + " : " + parts[1];
            symbols.add(tobeAdded);

            // Add the companies
            String[] words = parts[1].split(" ");

            for (int i = 0; i < words.length; i++) {
                ArrayList<String> arylst = new ArrayList<String>();

                if (companies.keySet().contains(words[i])) {
                    arylst = companies.get(words[i]);
                }

                if (!arylst.contains(tobeAdded)) {
                    arylst.add(tobeAdded);
                }
                
                companies.put(words[i], arylst);
            }

        }

        Collections.sort(symbols);
    }

    /**
     * Query for the stocks symbol s. Return only results that whose symbol
     * starts with s and, of those, return a maximum of n results.
     * Case-insensitive
     * 
     * @param s
     *            - the string to search for
     * @param n
     *            - the maximum number of results to return
     */
    protected Collection<String> searchSymbols(String s, int n) {
        Collection<String> l = new ArrayList<String>(n);
        Iterator<String> i = symbols.iterator();
        s = s.toUpperCase();
        boolean finished = false;

        while (n > 0 && i.hasNext() && !finished) {

            String current = i.next();
            if (current.split(":")[0].toUpperCase().startsWith(s)) {

                while (current.split(":")[0].toUpperCase().startsWith(s)
                        && n > 0) {

                    l.add(current);
                    current = i.next();
                    n--;
                }

                finished = true;
            }

        }

        return l;
    }

    /**
     * Query for the string s within company names. Return only results where s
     * is a prefix of a word that is part of the company name. Return at most n
     * matches. Case insensitive
     * 
     * @param s
     * @param n
     */
    protected Collection<String> searchNames(String s, int n) {
        Collection<String> l = new ArrayList<String>(n);
        Iterator<String> i = companies.keySet().iterator();
        s = s.toUpperCase();
        boolean finished = false;

        while (n > 0 && i.hasNext() && !finished) {

            String current = i.next();
            if (current.toUpperCase().startsWith(s)) {

                while (current.toUpperCase().startsWith(s) && n > 0) {

                    ArrayList<String> companiesThatContain = companies.get(current);
                    
                    if (companiesThatContain.size() >= n) {
                        // We're done at this point
                        List<String> a = companiesThatContain.subList(0, n);
                        l.addAll(a);
                        n = 0;
                    } else {
                        int listSize = companiesThatContain.size();
                        List<String> a = companiesThatContain.subList(0,
                                listSize);
                        l.addAll(a);
                        n -= listSize; // -1

                        // Keep going
                        current = i.next();
                    }

                }

                finished = true;
            }

        }

        return l;
    }
}
