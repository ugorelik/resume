package comp2402a2;

import java.util.AbstractList;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * This class implements the List interface using a collection of arrays of
 * sizes 1, 2, 3, 4, and so on. The main advantages of this over an
 * implementation like ArrayList is that there is never more than O(sqrt(size())
 * space being used to store anything other than the List elements themselves.
 * Insertions and removals take O(size() - i) amortized time.
 * 
 * This provides a space-efficient implementation of an ArrayList. The total
 * space used beyond what is required to store elements is O(sqrt(n))
 * 
 * @author morin
 * 
 * @param <T>
 *            the type of objects stored in this list
 */
public class RootishArrayStack<T> extends AbstractList<T> {
    /**
     * The type of objects stored in this list
     */
    Factory<T> f;

    /*
     * The blocks that contains the list elements
     */
    List<T[]> blocks;

    /**
     * The number of elements in the list
     */
    int n;

    /**
     * Convert a list index i into a block number TODO: This code is correct,
     * but very slow!
     * 
     * @param i
     * @return the index of the block that contains list element i
     */
    protected int i2b(int i) {
        // double db = 0.0; // TODO: Your code for computing b' goes here
        int b = (int) Math.ceil(quadEquation(i));
        // this crutch can be used to ensure correctness
        // even if k is off by a small value
        while (b * (b + 1) / 2 >= i + 1)
            b--;
        while ((b + 1) * (b + 2) / 2 < i + 1)
            b++;
        return b;
    }

    public double quadEquation(int i) {

        double A = 1.0/2.0;
        double B = 3.0/2.0;
        double C = (2.0/2.0) - (i + 1);
        

        double upper = ((B * -1) + Math.pow(        Math.pow(B, 2) - (4 * A * C)       , 0.5)    ) / (2*A);
        double lower = ((B * -1) - Math.pow(        Math.pow(B, 2) - (4 * A * C)       , 0.5)    ) / (2*A);

        // Saftey
        if (upper >= 0) { return upper;} 
        else { return lower; }

    }

    protected void grow() {
        blocks.add(f.newArray(blocks.size() + 1));
    }

    protected void shrink() {
        int r = blocks.size();
        while (r > 0 && (r - 2) * (r - 1) / 2 >= n) {
            blocks.remove(blocks.size() - 1);
            r--;
        }
    }

    public T get(int i) {
        if (i < 0 || i > n - 1)
            throw new IndexOutOfBoundsException();
        int b = i2b(i);
        int j = i - b * (b + 1) / 2;
        return blocks.get(b)[j];
    }

    public T set(int i, T x) {
        if (i < 0 || i > n - 1)
            throw new IndexOutOfBoundsException();
        int b = i2b(i);
        int j = i - b * (b + 1) / 2;
        T y = blocks.get(b)[j];
        blocks.get(b)[j] = x;
        return y;
    }

    /**
     * Needs to use system.arraycopy
     */
    public void add(int i, T x) {
        if (i < 0 || i > n)
            throw new IndexOutOfBoundsException();
        int r = blocks.size();
        if (r * (r + 1) / 2 < n + 1)
            grow();

        // Change this to a series of system.arraycopy's

        // Have to shift through the right taking in account the mulitple cases

        // BEGIN PASTE

        int b = i2b(i);
        int localPosI = i - b * (b + 1) / 2;
        int numBeforeLastBlock = (b) * (b - 1) / 2;

        int newB = blocks.size() - 1;

        while (newB > b) {

            int beforeNewB = (newB + 1) * (newB) / 2;

            if (beforeNewB != n) {
                // Copy from current to current. Shift everything over once. By
                // the number of eles in current
                System.arraycopy(blocks.get(newB), 0, blocks.get(newB), 1, blocks.get(newB).length - 1);
            }

            blocks.get(newB)[0] = blocks.get(newB - 1)[blocks.get(newB - 1).length - 1];

            newB--;

            if (newB == b) {
                System.arraycopy(blocks.get(newB), 0, blocks.get(newB), 1, blocks.get(newB).length - 1);
            }
        } // while

        blocks.get(b)[localPosI] = x;
        // set(i, x);
        n++; // TODO may have to move back
    }

    /**
     * Needs to use system.arraycopy
     */
    public T remove(int i) {

        if (i < 0 || i > n - 1)
            throw new IndexOutOfBoundsException();
        T x = get(i);

        int b = i2b(i);
        int localPosI = i - b * (b + 1) / 2;
        int numBeforeLastBlock = (b) * (b - 1) / 2;

        // If no shifting required
        if (n - numBeforeLastBlock == 1) {
            // Do nothing

        } else {
            // // Shift the local
            // System.arraycopy(blocks.get(b), localPosI + 1,
            // blocks.get(b),localPosI, blocks.get(b).length - (localPosI + 1));

            // There might be elements that need to be shifted up
            int newB = b + 1;
            while (newB < blocks.size()) {

                // Shift the last block up
                blocks.get(newB - 1)[blocks.get(newB - 1).length - 1] = blocks.get(newB)[0];

                // Now shift current back.
                System.arraycopy(blocks.get(newB), 1, blocks.get(newB), 0, blocks.get(newB).length - 1);

                newB++;

            } // while

        } // else

        n--;
        shrink();
        return x;

    }

    public int size() {
        return n;
    }

    public RootishArrayStack(Class<T> t) {
        f = new Factory<T>(t);
        n = 0;
        blocks = new ArrayList<T[]>();
    }

    public void clear() {
        blocks.clear();
        n = 0;
    }

    public boolean addAll(int i, Collection<? extends T> c) {

        int sizeOftemp = 0;
        
        for (int x = 0; x < blocks.size(); x++) {
            sizeOftemp += blocks.get(x).length;
        }
        
        T[] holdingList = f.newArray(sizeOftemp);
        
        int b = i2b(i);
        int localPosI = i - b * (b + 1) / 2;
        int oldBlockSize  = blocks.size();
        
        int totalEle = n + c.size();
        int r = blocks.size();
        while (totalEle > (r + 1) * (r) / 2) {
            grow();
            r = blocks.size();
        }
        
        int stepInHolding = 0;
        
        System.arraycopy(blocks.get(b), localPosI, holdingList, stepInHolding, blocks.get(b).length - localPosI); // Copy the existing elements to the holding list
        System.arraycopy(c.toArray(), stepInHolding, blocks.get(b), localPosI, blocks.get(b).length - localPosI); // Copy the new elements to the list
        stepInHolding += blocks.get(b).length - localPosI; // incremenet the stemp
        
        int newB = b;
        newB++;
        // Store the existing elements
        while (newB < oldBlockSize - 2) {
            
            // Everything here will start at the begining and go to the end
            System.arraycopy(blocks.get(newB), localPosI, holdingList, stepInHolding, blocks.get(newB).length); // Copy the existing elements to the holding list
            
            // If there are still elements to copy
            if (stepInHolding < c.size() - 1) {
                System.arraycopy(c.toArray(), stepInHolding, blocks.get(newB), localPosI, blocks.get(newB).length); // Copy the new elements to the list
            }
            
            stepInHolding += blocks.get(newB).length;
            newB++;
        }

        // THe last block, we don't want to add null values
        int currentBlockSize = ((newB + 1) * (newB) )/ 2;
        
        int numtoCopy = -1;
        System.arraycopy(blocks.get(newB), 0, holdingList, stepInHolding, n - currentBlockSize );
        if (stepInHolding < c.size() - 1) {
            numtoCopy = c.size() - stepInHolding;
            System.arraycopy(c.toArray(), stepInHolding, blocks.get(newB), 0, numtoCopy); // Copy the new elements to the list TODO used to localPosI not 0
        }
        
        stepInHolding += n - currentBlockSize;
        // newB++ TODO this may need to be here
        
        // Now we have either added all the from the source up to the size of the remaining elements
        // we still need to check if there are elements left in the source (list c)
        if (stepInHolding < c.size() - 1) {
            
            while (oldBlockSize > newB) {
                // Must be less than the current block size
                int numtoAdd = -1;
                
                if ((c.size() - 1 ) - stepInHolding > blocks.get(newB).length) {
                    numtoAdd = blocks.get(newB).length;
                } else {
                    numtoAdd = (c.size() - 1 ) - stepInHolding;
                }
                
                System.arraycopy(c.toArray(), stepInHolding, blocks.get(newB), 0, numtoAdd);
                newB++;
            }
        }
        
        // Now we begin adding, although the previous might still have room
/**
 *  INSERT CODE HERE
 */
        stepInHolding = 0;
        
        if (numtoCopy > 0 && blocks.get(newB).length - numtoCopy >0) {
            // We need to fill in the last row
            System.arraycopy(holdingList, stepInHolding, blocks.get(newB), numtoCopy, blocks.get(newB).length - numtoCopy);
            stepInHolding += blocks.get(newB).length - numtoCopy;
        }
        
        newB++;
        
        // Now all of the new elements are in the list.
        // At this point we need to append everything in our holding list
        
        /**
         *  YOU ARE HERE FINISH THIS.. YOU JUST NEED TO FINISH APPEND
         * 
         */
        while(blocks.size() > newB) {
            
            int numtoAdd = -1;
            
            if ((holdingList.length - stepInHolding - 1) > blocks.get(newB).length) {
                numtoAdd = blocks.get(newB).length;
            } else {
                numtoAdd = holdingList.length - stepInHolding - 1;
            }
            
            System.arraycopy(holdingList, stepInHolding, blocks.get(newB), 0, numtoAdd);
            stepInHolding += numtoAdd;
            newB++;
        }
        
        n += c.size();
        
        return true;
        
    }

     @SuppressWarnings("all")
    public static void main(String[] args) {
        List rootish = new RootishArrayStack(String.class);

        rootish.add("a");
        rootish.add("b");
        rootish.add("c");
        rootish.add("d");
        rootish.add("e");
        rootish.add("f");
        rootish.add("g");
        rootish.add("h");
        rootish.add("i");
        rootish.add("j");
        // rootish.add("k");

        // rootish.add(0, "z");

        // System.out.println(rootish);

        Collection c = new ArrayList();

        c.add("1");
        c.add("2");
        c.add("3");
        c.add("4");
        c.add("5");
        // c.add("6");
        // c.add("7");
        // c.add("8");
        // c.add("9");
        // c.add("10");
        // c.add("11");

        rootish.addAll(4, c);

        System.out.println(rootish);
    }
}
