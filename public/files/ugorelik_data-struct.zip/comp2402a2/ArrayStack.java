package comp2402a2;

import java.util.AbstractList;
import java.util.Collection;
import java.util.List;

/**
 * This is a copy of the JCF class ArrayList.  It implements the List
 * interface as a single array a.  Elements are stored at positions
 * a[0],...,a[size()-1].  Doubling/halving is used to resize the array
 * a when necessary. 
 * @author morin
 *
 * @param <T> the type of objects stored in the List
 */
public class ArrayStack<T> extends AbstractList<T> {
	/**
	 * keeps track of the class of objects we store
	 */
	Factory<T> f;
	
	/**
	 * The array used to store elements
	 */
	T[] a;
	
	/**
	 * The number of elements stored
	 */
	int n;
	

	/**
	 * Grow the internal array
	 */
	protected void grow() {
		T[] b = f.newArray(a.length*2);
		for (int i = 0; i < n; i++) {
			b[i] = a[i];
		}
		a = b;
	}
	
	/**
	 * Shrink the internal array if too much space is being wasted
	 */
	protected void shrink() {
		if (n > 0 && n < a.length / 3) {
			T[] b = f.newArray(n*2);
			for (int i = 0; i < n; i++)
				b[i] = a[i];
			a = b;			
 		}
	}
	
	/**
	 * Constructor
	 * @param t0 the type of objects that are stored in this list
	 */
	public ArrayStack(Class<T> t) {
		f = new Factory<T>(t);
		a = f.newArray(1);
		n = 0;
	}

	public T get(int i) {
		if (i < 0 || i > n - 1) throw new IndexOutOfBoundsException();
		return a[i];
	}
	
	public int size() {
		return n;
	}
	
	public T set(int i, T x) {
		if (i < 0 || i > n - 1) throw new IndexOutOfBoundsException();
		T y = a[i];
		a[i] = x;
		return y;
	}
	
	public void add(int i, T x) {
		if (i < 0 || i > n) throw new IndexOutOfBoundsException();
		if (n + 1 > a.length)
			grow();
		for (int j = n; j > i; j--) 
			a[j] = a[j-1];
		a[i] = x;
		n++;
	}
	
	public T remove(int i) {
		if (i < 0 || i > n - 1) throw new IndexOutOfBoundsException();
		T x = a[i];
		for (int j = i; j < n-1; j++) 
			a[j] = a[j+1];
		n--;
		shrink();
		return x;
	}

	// The following methods are not strictly necessary. The parent
	// class, AbstractList, has default implementations of them, but
	// our implementations are more efficient - especially addAll
	
	/**
	 * A small optimization for a frequently used method
	 */
	public boolean add(T x) {
		if (n + 1 > a.length)
			grow();
		a[n++] = x;
		return true;
	}
	
	/**
	 * We override addAll because AbstractList implements it by 
	 * repeated calls to add(i,x), which can take time 
	 * O(size()*c.size()).  This happens, for example, when i = 0.
	 * This version takes time O(size() + c.size()).
	 */
	public boolean addAll(int i, Collection<? extends T> c) {
		if (i < 0 || i > n) throw new IndexOutOfBoundsException();
		int k = c.size();
		while (n + k > a.length)
			grow();
		for (int j = n+k-1; j >= i+k; j--)
			a[j] = a[j-k];
		for (T x : c)
			a[i++] = x;
		n += k;		
		return true;
	}
	
	/**
	 * We override this method because AbstractList implements by
	 * repeated calls to remove(size()), which takes O(size()) time.
	 * This implementation runs in O(1) time.
	 */
	public void clear() {
		n = 0;
		shrink();
	}

	/**
	 * Test code for my array implementation
	 * @param args command line arguments
	 */
	public static void main(String[] args) {
		ArrayStack<String> mal = new ArrayStack<String>(String.class) {};
		mal.add("hello");
		mal.add("world");
		System.out.println(mal);
		
		List<Integer> l = new ArrayStack<Integer>(Integer.class);
		int n = 1000000;
		long start, stop;
		start = System.nanoTime();
		for (int i = 0; i < n; i++) {
			l.add(new Integer(i));
		}
		stop = System.nanoTime();
		System.out.println("Insertion in " + 1e-9*(stop-start) + " seconds");

		start = System.nanoTime();
		l.clear();
		while (l.size()>0) {
			l.remove(l.size()-1);
		}
		stop = System.nanoTime();
		System.out.println("Removal in " + 1e-9*(stop-start) + " seconds");

	}
}
