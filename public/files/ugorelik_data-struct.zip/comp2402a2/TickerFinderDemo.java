package comp2402a2;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

public class TickerFinderDemo extends JPanel implements DocumentListener   {
	private static final long serialVersionUID = 1819947608798515533L;

	protected static String filename  = "companies.csv";
	
	/**
	 * This field stores the company's market symbol (e.g., GOOG)
	 */
	protected JTextField queryField;
		
	/**
	 * Where search results are displayed
	 */
	protected JTextArea symbolsArea;
	protected JTextArea namesArea;
	
	/**
	 * The underlying search stucture
	 */
	protected TickerFinder finder;

	/**
	 * Start a demonstration with a Textbox for typing and a TextArea for
	 * showing possible completions.
	 */
	public TickerFinderDemo(String filename) {
		// do gui stuff
		super(new GridBagLayout());

		queryField = new JTextField(20);
		queryField.getDocument().addDocumentListener(this);

		symbolsArea = new JTextArea(15, 40);
		symbolsArea.setEditable(false);
		symbolsArea.setLineWrap(true);
		symbolsArea.setWrapStyleWord(true);

		namesArea = new JTextArea(15, 40);
		namesArea.setEditable(false);
		namesArea.setLineWrap(true);
		namesArea.setWrapStyleWord(true);

		GridBagConstraints c = new GridBagConstraints();
		c.gridwidth = GridBagConstraints.REMAINDER;
		
		c.fill = GridBagConstraints.HORIZONTAL;
		add(queryField, c);
		
		c.fill = GridBagConstraints.BOTH;
		c.weightx = 1.0;
		c.weighty = 1.0;
		add(symbolsArea, c);
		add(namesArea, c);

		// prepare the completion list
		finder = new TickerFinder();
		try {
			finder.loadCompaniesFromFile(filename);
		} catch (Exception e) {
			System.err.println("Error opening file: " + filename);
			System.exit(-1);
		}
	}

	/**
	 *  Search for completions of the text in the TextField
	 */
    public void search() {
        String s = queryField.getText();
        
        if (s.length() == 0) { 
        	symbolsArea.setText("");
        	namesArea.setText("");
        } else {
	        Collection<String> companies = finder.searchSymbols(s, 10);
	        Iterator<String> i = companies.iterator();
	        String text = "";
	        while (i.hasNext()) {
	        	text = text + i.next();
	        	if (i.hasNext()) {
	        		text = text + "\n";
	        	}
	        }
	        symbolsArea.setText(text);
	        
	        // Now search for companies
	        companies = finder.searchNames(s, 10);
	        i = companies.iterator();
	        text = "";
	        while (i.hasNext()) {
	        	text = text + i.next();
	        	if (i.hasNext()) {
	        		text = text + "\n";
	        	}
	        }
	        namesArea.setText(text);
        }
    }
    
    /**
     * Create the GUI and show it.  For thread safety,
     * this method should be invoked from the
     * event dispatch thread.
     */
    private static void createAndShowGUI(String filename) {
        //Create and set up the window.
        JFrame frame = new JFrame("TickerFinderDemo");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //Add contents to the window.
        frame.add(new TickerFinderDemo(filename));

        //Display the window.
        frame.pack();
        frame.setVisible(true);
    }
    
    public void insertUpdate(DocumentEvent ev) {
        search();
    }
    
    public void removeUpdate(DocumentEvent ev) {
        search();
    }
    
    public void changedUpdate(DocumentEvent ev) {
    	search();
    }

    public static void main(String[] args) {
    	if (args.length > 0) {
    		filename = args[0];
    	}
        //Schedule a job for the event dispatch thread:
        //creating and showing this application's GUI.
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                createAndShowGUI(filename);
            }
        });
    }
}
