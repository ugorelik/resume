package comp2402a2;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * Assignment class - override the methods below for performance
 * 
 * @author morin
 * 
 * @param <T>
 */
public class FastArrayDeque<T> extends ArrayDeque<T> {


    public FastArrayDeque(Class<T> t) {
        super(t);
    }

    public void grow() {

        int size = 2;
        while (size< a.length * 2) {
            size *= 2;
        }
        
        T[] b = f.newArray(size);

        int numOfEle = Math.abs(a.length - (j & (a.length - 1)) - n);

        // No wrap around
        if (j == 0) {
            System.arraycopy(a, 0, b, 0, a.length);
        } else {
            // With wrap around
            System.arraycopy(a, j & (a.length - 1), b, 0, a.length - (j & (a.length - 1)));
            System.arraycopy(a, 0, b, n, numOfEle);
        }

        a = b;
        j = 0;
    }

    public void shrink() {

        if (n > 0 && n < a.length / 4) {

            int size = 2;
            while (size < n*2) {
                size *=2;
            }
            
            T[] b = f.newArray(size);

            if (j == 0) {
                System.arraycopy(a, 0, b, 0, b.length);
            } else {
                
                int numCopy = a.length - n - (j & (a.length - 1));
                
                System.out.println(b.length);
                System.out.println(n);
                
                // With wrap
                System.arraycopy(a, j& (a.length - 1), b, 0, b.length - j);
                System.arraycopy(a, 0, b, b.length - j, n - (b.length - j) + 1);
            }

            a = b;
            j = 0;
        }
    }

    public void add(int i, T x) {

        // Pre-process
        if (i < 0 || i > n)
            throw new IndexOutOfBoundsException();
        if (n + 1 > a.length)
            grow();


        if (i == n) {
            // Add to the tail nothing needs to be shifted
        } else if (i == 0) {
            // Insert in the head
            j--;
        }
        
        // Not the head or the tail
        else {

            // No wrap
            if (j == 0) {
                // Shift right
                System.arraycopy(a, i, a, i + 1, n - i);
            } else {
                // With wrap
                
                // Dealing with j to a.length
                if ( ((j + i) & (a.length - 1)) == j + i) {
                    // Shift left
                    System.arraycopy(a, (j + i) & (a.length), a, ((j + i - 1)  & (a.length - 1)), i - 1);
                } else {
                    // 0 to 
                    // Shift right
                    System.arraycopy(a, (j + i) &(a.length - 1), a, (j + i + 1) &(a.length - 1), n - (a.length - j)); 
                }
            }
            
            
        }

        // Add the element
        a[(j + i) & (a.length - 1)] = x;

        n++;
    }

    public T remove(int i) {

        if (i < 0 || i > n - 1)
            throw new IndexOutOfBoundsException();

        T returning = a[(j + i) & (a.length - 1)];

        if (i == n - 1) {
            // Remove the tail
        } else if (i == 0) {
            // Remove the head
            j++;
        } else {
            // No wrap
            if (j == 0) {
                System.arraycopy(a, (i + 1), a, i, n - (i + 1));
            } else {
                // With Wrap
                if ( ((j + i) & (a.length - 1)) == j + i) {
                    // We don't need to touch the wrap we only need to deal with things in between j and a.lengtjh
                    System.arraycopy(a, j, a, j + 1, i);
                    j++;
                } else {
                    // The removal is after the wrap, i.e. 0 to 
                    // We want to shift left
                    System.arraycopy(a, (j + i + 1) &(a.length - 1), a, (j + i) &(a.length - 1), j - (i + 1));
                }
            } // else -  wrap

        } // else - not head or tail

        n--;
        shrink();
        return returning;
    }

    public boolean addAll(int i, Collection<? extends T> c) {
        return super.addAll(i, c);
    }

    @SuppressWarnings("all")
    public static void main(String[] args) {

        List<String> test = new FastArrayDeque(String.class);

        test.add("a");
        test.add("b");
        test.add("c");
        test.add("d");

        Collection c = new ArrayList();

        c.add("1");
        c.add("2");
        c.add("3");
        c.add("4");
        c.add("5");
        c.add("6");
        c.add("7");
        c.add("8");
        c.add("9");
        c.add("10");
        c.add("11");
        
        
        System.out.println(test);

    }
}

// System.out.println("j: " + j);
// System.out.println("length: " + a.length);
// System.out.println("num of ele: " + n);
//        
// System.out.println("j &: " + (j & (a.length -1)) );
// System.out.println("j - 1 &: " + ((j - 1) & (a.length -1)) );
//        
// System.out.println();
// System.out.println();
// System.out.println();