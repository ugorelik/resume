package comp2402a2;

import java.util.AbstractQueue;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Queue;

/**
 * An implementation of the Queue<T> interface using an array
 * 
 * All operations takes constant amortized time.
 * @author morin
 *
 * @param <T>
 */
public class ArrayQueue<T> extends AbstractQueue<T> {
	/**
	 * The class of elements stored in this queue
	 */
	Factory<T> f;
	
	/**
	 * Array used to store elements
	 */
	T[] a;
	
	/**
	 * Index of next element to de-queue
	 */
	int j;
	
	/**
	 * Number of elements in the queue
	 */
	int n;
	
	/**
	 * Grow the internal array
	 */
	protected void grow() {
		T[] b = f.newArray(a.length * 2);
		for (int k = 0; k < n; k++) 
			b[k] = a[(j+k) % a.length];
		a = b;
		j = 0;
	}
	
	/**
	 * Shrink the internal array if too much space is being wasted
	 */
	protected void shrink() {
		if (n > 0 && n < a.length / 4) {
			T[] b = f.newArray(n * 2);
			for (int k = 0; k < n; k++)
				b[k] = a[(j+k) % a.length];
			a = b;
			j = 0;			
		}
	}

	/**
	 * Constructor
	 */
	public ArrayQueue(Class<T> t) {
		f = new Factory<T>(t);
		a = f.newArray(1);
		j = 0;
		n = 0;
	}
	
	/**
	 * Return an iterator for the elements of the queue. 
	 * This iterator does not support the remove operation
	 */
	public Iterator<T> iterator() {
		class QueueIterator implements Iterator<T> {
			int k;
			
			public QueueIterator() {
				k = 0;
			}

			public boolean hasNext() {
				return (k < n);
			}
			
			public T next() {
				if (k > n) throw new NoSuchElementException();
				T x = a[(j+k) % a.length];
				k++;
				return x;
			}
			
			public void remove() {
				throw new UnsupportedOperationException();
			}
		}
		return new QueueIterator();
	}

	public int size() {
		return n;
	}

	public boolean offer(T x) {
		if (n + 1 > a.length) 
			grow();
		a[(j+n) % a.length] = x;
		n++;
		return true;
	}

	public T peek() {
		T x = null;
		if (n > 0) {
			x = a[j];
		}
		return x;
	}

	public T poll() {
		T x = null;
		if (n > 0) {
			x = a[j];
			j = (j + 1) % a.length;
			n--;
			shrink();
		}
		return x;
	}
	
	public static void main(String args[]) {
		int m = 10000, n = 50;
		Queue<Integer> q = new ArrayQueue<Integer>(Integer.class);
		for (int i = 0; i < m; i++) {
			q.add(new Integer(i));
			if (q.size() > n) {
				Integer x = q.remove();
				assert(x == i - n);
			}
		}
		Iterator<Integer> i = q.iterator();
		while (i.hasNext()) {
			System.out.println(i.next());
		}
	}

}
