package comp2402a2;

import java.util.Collections;

public class Treque<T> extends DualArrayDeque<T> {

    DualArrayDeque<T> front;
    DualArrayDeque<T> back;

    public Treque(Class<T> t) {
        super(t);
        front = new DualArrayDeque<T>(t);
        back = new DualArrayDeque<T>(t);

    }

    protected DualArrayDeque<T> newDualDeque(Class<T> t) {
        return new DualArrayDeque<T>(t);
    }

    protected void balance() {
        int n = size();
        if (3 * front.size() < back.size()) {
            int s = n / 2 - front.size();
            DualArrayDeque<T> l1 = newDualDeque(f.t);
            DualArrayDeque<T> l2 = newDualDeque(f.t);
            l1.addAll(back.subList(0, s));
            Collections.reverse(l1);
            l1.addAll(front);
            l2.addAll(back.subList(s, back.size()));
            front = l1;
            back = l2;
        } else if (3 * back.size() < front.size()) {
            int s = front.size() - n / 2;
            DualArrayDeque<T> l1 = newDualDeque(f.t);
            DualArrayDeque<T> l2 = newDualDeque(f.t);
            l1.addAll(front.subList(s, front.size()));
            l2.addAll(front.subList(0, s));
            Collections.reverse(l2);
            l2.addAll(back);
            front = l1;
            back = l2;
        }
    }

}
