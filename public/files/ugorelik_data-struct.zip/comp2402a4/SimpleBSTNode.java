package comp2402a4;

public class SimpleBSTNode<T extends Comparable<T>> extends
		BSTNode<SimpleBSTNode<T>, T> {

}
