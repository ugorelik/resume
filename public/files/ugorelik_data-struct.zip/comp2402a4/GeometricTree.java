package comp2402a4;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Random;

public class GeometricTree extends BinaryTree<GeometricTreeNode> {

	int prevWidth = 0;
	int width = 0;
	int height = 0;
	Queue<GeometricTreeNode> leftqueue = new LinkedList<GeometricTreeNode>();

	public GeometricTree() {
		super(new GeometricTreeNode());
	}

	public void inorderDraw() {
		assignLevels();
		assignWidthInorder(root, width);
	}

	protected void assignWidthInorder(GeometricTreeNode u, int r) {
		if (u == null)
			return;
		assignWidthInorder(u.left, width);
		u.position.x = width;
		width++;
		assignWidthInorder(u.right, width);
	}

	/**
	 * Draw each node so that it's x-coordinate is as small as possible without
	 * intersecting any other node at the same level the same as its parent's
	 */
	public void leftistDraw() {
		assignLevels();

		Queue<GeometricTreeNode> queue = new LinkedList<GeometricTreeNode>();
		queue.add(root);
		int counter = 0;
		int layer = 0;
		while (!queue.isEmpty()) {
			GeometricTreeNode u = queue.remove();

			if (u.position.y != layer) {
				counter = 0;
				layer = u.position.y;
			}

			u.position.x = counter++;

			if (u.left != null) {
				queue.add(u.left);
			}

			if (u.right != null) {
				queue.add(u.right);
			}

		}

	}

	public void leftistDraw(GeometricTreeNode u, int r) {

		if (u == null)
			return;

		leftqueue.add(u.left);
		leftqueue.add(u.right);

	}

	public void balancedDraw() {
		root.size = precomputeSize();
		root.position.x = 0;
		root.position.y = 0;
		
		drawBalance(root);
	}
	
	private void drawBalance(GeometricTreeNode u){
		
		if (u.left != null && u.right !=null){
			// both available
			if (u.left.size <= u.right.size){
				// Then draw the left directly below
				u.left.position.y = u.position.y + 1;
				u.left.position.x = u.position.x;
				
				drawBalance(u.left);
//				width = width + u.left.size;
				width++;
//				prevWidth = width;
				u.right.position.y = u.position.y;
				u.right.position.x = width;
//				width = width - u.left.size - 1;
				drawBalance(u.right);
				
			} else {
				// Other wise draw the right directly below
				u.right.position.y = u.position.y + 1;
				u.right.position.x = u.position.x;
				
				drawBalance(u.right);
//				width = width + u.right.size;
				width++;
//				prevWidth = width;
				u.left.position.y = u.position.y;
				u.left.position.x = width;
//				width = width - u.right.size - 1;
				
				drawBalance(u.left);
			}
			
		} else if (u.left != null && u.right == null){
			// Right is null
			u.left.position.y = u.position.y + 1;
			u.left.position.x = u.position.x;
			
			// Continue left
			drawBalance(u.left);
			
		} else if (u.left == null & u.right != null) {
			// left is null
			u.right.position.y = u.position.y + 1;
			u.right.position.x = u.position.x;
			
			// Continue right
			drawBalance(u.right);
		}
	}

	public int precomputeSize() {
		return precomputeSize(root);
	}

	/**
	 * Taken from the notes
	 * @param u
	 * @return
	 */
	public int precomputeSize(GeometricTreeNode u) {
		if (u == null) return 0;
		int sl = precomputeSize(u.left);
		int sr = precomputeSize(u.right);
		u.size = 1 + sl + sr;
		return 1 + sl + sr;
	}


	protected void assignLevels() {
		assignLevels(root, 0);
	}

	protected void assignLevels(GeometricTreeNode u, int i) {
		if (u == null)
			return;
		u.position.y = i;
		assignLevels(u.left, i + 1);
		assignLevels(u.right, i + 1);
	}

	public static void main(String[] args) {
		GeometricTree t = new GeometricTree();
		// galtonWatsonTree(t, 100);
		// System.out.println(t);
		t.inorderDraw();
		System.out.println(t);
	}

}
