package comp2402a4;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.SortedSet;
import java.util.TreeSet;

public class ScapegoatTreeOld<T extends Comparable<T>> extends BinarySearchTree<ScapegoatNode<T>, T> {
    /**
     * The number of elements (and nodes) in the tree
     */
    int n;

    /**
     * An overestimate of the number of n
     */
    int q;
    
    int counter = 0;

    public ScapegoatTreeOld(ScapegoatNode<T> is) {
        super(is);
    }

    public int size() {
        return n;
    }

    public boolean remove(Object x) {
        if (super.remove(x)) {
            n--;
            if (2 * n < q) {
                rebuild(root); // Rebuild entire thing into bst
                q = n;
            }
            return true;
        }
        return false;
    }

    /**
     * Compute the ceiling of log_{3/2}(q)
     * 
     * @param q
     * @return the ceiling of log_{3/2}(q)
     */
    protected static final int log32(int q) {
        final double log23 = 2.4663034623764317;
        return (int) Math.ceil(log23 * Math.log(q));
    }

    /**
     * Rebuild the subtree rooted at u so that it is perfectly balanced
     * 
     * @param u
     */
    @SuppressWarnings("unchecked")
    protected void rebuild(ScapegoatNode<T> u) {
        ScapegoatNode<T> oldParent = u.parent; // Hold on to the parent node
    	ScapegoatNode<T>[] a = (ScapegoatNode<T>[]) Array.newInstance(sampleNode.getClass(), size(u));        // Create a new array
    	int mid = a.length/2;
        u = a[mid]; // Set the new u
        
        if (oldParent == null) {    // If u is the root
            u.parent = null;        // Set new u to root
            root = u;
        } else if (u.x.compareTo(oldParent.x) < 0) {
            oldParent.left = u;
            u.parent = oldParent;
        } else {
            oldParent.right = u;
            u.parent = oldParent;
        }
        
//      Reset the pointers        
        for (int x = 0; x < mid; x++){
        	a[x].left = null;
        	a[x].right = null;
        	a[x].parent = null;
        }
        
        for (int x = mid + 1; x < a.length -1; x++){
        	a[x].left = null;
        	a[x].right = null;
        	a[x].parent = null;
        }
        
        buildBST(u, a, mid); // Call recursive method
    }

    public void buildBST(ScapegoatNode<T> u, ScapegoatNode<T>[] a, int mid) {

    	if (mid == 0) return;
    	// Set pointers for left
        u.left = a[mid/2];
        u.left.parent = u;
        
        // Make new lists
        
        buildBST(u.left, a, mid/2);  // Recurse
        
        // Set pointers for right
        if (((a.length / 2) + mid/2) == a.length/2) return;
        u.right = a[(a.length / 2) + mid/2];
        u.right.parent = u;
        
        // Make new lists
        buildBST(u.right, a, mid/2);// Recurse

    }
    

    public void populateArray(ScapegoatNode<T> u, ScapegoatNode<T>[] a) {
        if (u == null)
            return;

        populateArray(u.left, a);
        a[counter] = u;
        counter++;
        populateArray(u.right, a);
    }

    public boolean add(T x) {
        // first do basic insertion, while keeping
        // track of depth
        ScapegoatNode<T> u = newNode();
        u.x = x;
        int d = 0;
        ScapegoatNode<T> w = root;
        if (w == null) {
            root = u;
            n++;
            q++;
            return true;
        }
        boolean done = false;
        while (!done) {
            int res = x.compareTo(w.x);
            if (res < 0) {
                if (w.left == null) {
                    w.left = u;
                    u.parent = w;
                    done = true;
                } else {
                    w = w.left;
                }
            } else if (res > 0) {
                if (w.right == null) {
                    w.right = u;
                    u.parent = w;
                    done = true;
                }
                w = w.right;
            } else {
                return false;
            }
            d++;
        }
        n++;
        q++;
        if (d > log32(q)) {
            // depth exceeded, find scapegoat
            while (3 * size(w) <= 2 * size(w.parent))
                w = w.parent;
            rebuild(w.parent);
        }
        return true;
    }

    public static void main(String[] args) {
         ScapegoatTreeOld<Integer> t
         = new ScapegoatTreeOld<Integer>(new ScapegoatNode<Integer>());
         int n = 100000;
//         int n = 100;
         
         correctnessTests(t, n);
         performanceTests(t);
    }

}
