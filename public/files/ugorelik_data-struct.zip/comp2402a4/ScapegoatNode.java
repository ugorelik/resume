package comp2402a4;

public class ScapegoatNode<T extends Comparable<T>> extends BSTNode<ScapegoatNode<T>, T> {
    
}
