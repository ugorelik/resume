//package comp2402a4;
//
//import javax.swing.*;
//
//import comp2402.ScapegoatNode;
//import comp2402.ScapegoatTree;
//
//import java.awt.*;
//import java.awt.event.*;
//import comp2402.*;
//
//public class ScapegoatDemo extends JPanel {
//	int[][] coords;
//	ScapegoatTree t;
//	int i;
//	int x;
//
//	public static int SEPARATION = 20;
//
//    public ScapegoatDemo (ScapegoatTree tree) {
//        super();
//        t = tree;
//        i=0;
//        x=10;
//      //  y=150;
//        coords = new int[20][2];
//
//        assignCoordinates((ScapegoatNode)t.root);
//        i=0;
//        assignLevels((ScapegoatNode)t.root,150);
//        i=0;
//        repaint();
//        System.out.println("this " + coords[0][1]);
//    }
//
//    public void assignLevels(ScapegoatNode u, int y){
//    	if(u.left !=null)
//    		assignLevels((ScapegoatNode)u.left,y+SEPARATION);
//    	coords[i][1]=y;
//    	i++;
//    	System.out.println("Y is " + y);
//    	if(u.right != null)
//    		assignLevels((ScapegoatNode)u.right,y+SEPARATION);
//    }
//
//    public void assignCoordinates(ScapegoatNode u){
//		if(u==null)return;
//		if(u.left != null)
//			assignCoordinates((ScapegoatNode)u.left);
//		coords[i][0]=x;
//		x+=SEPARATION;
//		i++;
//		if(u.right!= null)
//			assignCoordinates((ScapegoatNode)u.right);
//    }
//
//    public void paint(Graphics g){
//    	recursiveDraw(g,(ScapegoatNode)t.root);
//    	i=0;
//    }
//
//	public void testFunction(Graphics g){
//		g.drawLine(30,30,50,50);
//	}
//
//    public void recursiveDraw(Graphics g,ScapegoatNode u){
//    	if(u==null)return;
//    	if(u.left != null)
//			recursiveDraw(g,(ScapegoatNode)u.left);
//		g.drawString(u.toString(),coords[i][0],coords[i][1]);
//		i++;
//		System.out.println("drawing" + u);
//		if(u.right!= null)
//			recursiveDraw(g,(ScapegoatNode)u.right);
//    }
//
//    public static void main(String args[]) {
//        ScapegoatTree<Integer> t
//		   = new ScapegoatTree<Integer>(new ScapegoatNode<Integer>());
//		t.add(6);
//        t.add(3);
//      //  t.add(5);
//        t.add(2);
//        t.add(1);
//
//        JFrame f = new JFrame("test");
//        f.getContentPane().add(new ScapegoatDemo(t));
//        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//		f.setSize(300,300);
//		f.setVisible(true);
//		f.setResizable(false);
//		System.out.println(t);
//
//    }
//}

