package comp2402a4;

public class SimpleBinaryTreeNode extends BinaryTreeNode<SimpleBinaryTreeNode> {

}
